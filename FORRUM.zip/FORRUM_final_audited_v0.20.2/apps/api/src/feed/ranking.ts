export interface FeedScoreInput {
  mode: string;
  format: 'POST' | 'TOPIC';
  createdAtMs: number;
  lastActivityAtMs: number;
  nowMs: number;
  commentCount: number;
  reactionCount: number;
  bookmarkCount: number;
  viewCount: number;
  isCommunitySubscribed: boolean;
  isAuthorFollowed: boolean;
  matchingTagCount: number;
  isPinned: boolean;
}

export interface FeedScoreResult {
  score: number;
  reason: string;
  personallyRelevant: boolean;
  discussed: boolean;
}

export function calculateFeedScore(input: FeedScoreInput): FeedScoreResult {
  const ageHours = Math.max(0, (input.nowMs - input.createdAtMs) / 3_600_000);
  const activityHours = Math.max(0, (input.nowMs - input.lastActivityAtMs) / 3_600_000);
  const engagementRaw = input.commentCount * 3 + input.reactionCount * 2 + input.bookmarkCount * 2 + input.viewCount / 30;
  const engagement = Math.min(48, Math.log1p(engagementRaw) * 10);
  const freshness = input.format === 'POST'
    ? Math.max(0, 38 - ageHours * 0.65)
    : Math.max(0, 32 - activityHours * 0.22);
  const subscription = input.isCommunitySubscribed ? 55 : 0;
  const authorFollow = input.isAuthorFollowed ? 34 : 0;
  const tagAffinity = Math.min(28, input.matchingTagCount * 14);
  const popularBonus = input.commentCount >= 5 ? 8 : 0;
  // Продвижение помогает получить показ, но не способно перекрыть отсутствие интереса и качества.
  const pinBonus = input.isPinned ? 10 : 0;

  const personallyRelevant = Boolean(subscription || authorFollow || tagAffinity);
  const discussed = engagement >= 20 || input.commentCount >= 3 || input.reactionCount >= 4 || input.bookmarkCount >= 2;

  const reason = subscription
    ? 'Вы подписаны на сообщество'
    : authorFollow
      ? 'Вы подписаны на автора'
      : tagAffinity
        ? 'Совпадает с вашими хэштегами'
        : engagement >= 25
          ? 'Популярно и обсуждается'
          : 'Новое на FORRUM';

  if (input.mode === 'new') return { score: input.createdAtMs, reason: 'Новое на FORRUM', personallyRelevant, discussed };
  if (input.mode === 'popular') return { score: engagement + freshness * 0.35, reason, personallyRelevant, discussed };
  return {
    score: subscription + authorFollow + tagAffinity + engagement + freshness + popularBonus + pinBonus,
    reason,
    personallyRelevant,
    discussed,
  };
}
